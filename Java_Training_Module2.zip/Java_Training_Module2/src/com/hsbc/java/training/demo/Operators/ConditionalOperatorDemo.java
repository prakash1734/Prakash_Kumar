package com.hsbc.java.training.demo.Operators;
public class ConditionalOperatorDemo {
    
    public static void main(String[] args) {
        
        /*&&  conditional -AND operator
        ||  conditional-OR operator
        ? : ternary operator in form of: A ? B : C*/
        
        int x=10;
        int y=20;
        
        if((x>9) && (y>9)){
            System.out.println("Both x and y greater than 9");
        }
        
        if ((x > 11) || (y > 10)) {
            System.out.println("Either x or y is greater than 10");
        }
        
        // Example ternary operator in form of: A ? B : C
        
        int result = (x > 10) ? x : y;
        
        System.out.println("result 1 is: " + result);
        
        result= (y > 10) ? x : y;
        
        System.out.println("result 2 is : " +result);
    }
}