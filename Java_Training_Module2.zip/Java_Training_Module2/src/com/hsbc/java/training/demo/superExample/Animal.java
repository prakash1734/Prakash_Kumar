package com.hsbc.java.training.demo.superExample;
public class Animal {
    
    String color="white";  
}