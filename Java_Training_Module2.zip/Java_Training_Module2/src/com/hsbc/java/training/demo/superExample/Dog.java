package com.hsbc.java.training.demo.superExample;
public class Dog extends Animal{
    
    String color="black";  
    void printColor(){  
        
    //prints color of Dog class 
    System.out.println(color); 
    
    //prints color of Animal class  
    System.out.println(super.color);
}
}