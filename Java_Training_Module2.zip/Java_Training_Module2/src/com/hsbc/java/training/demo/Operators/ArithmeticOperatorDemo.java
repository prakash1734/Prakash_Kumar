package com.hsbc.java.training.demo.Operators;
public class ArithmeticOperatorDemo {
    
    
    
    public static void main(String[] args) {
        
        /*Arithmetic Operator Example : 
         * + Addition (and strings concatenation) operator
         * -  Subtraction operator
         * *  Multiplication operator
         * /  Division operator 
         *  % Remainder operator*/
        
        int a= 5;
        int b= 10;
        
        int result=a+b;
        System.out.println("a + b : "+result);
        
        result=a-b;
        System.out.println("a - b : "+result);
        
        result=a*b;
        System.out.println("a * b : "+result);
        
        result=b/a;
        System.out.println("b / a : "+result);
        
        result=a % 2;
        System.out.println("a % b : "+result);
        
        /*Addition operator (+) can also be used for joining two or more strings together (strings concatenation)*/
        
        String firstName="Prakash";
        String lastName="Kumar";
        String display= "Hello " +firstName+ " " +lastName +"!";
        System.out.println(display);
        
    }
}