package com.hsbc.java.training.demo.Operators;
public class PrefixPostfixDemo {
    public static void main(String[] args) {
        
    /* Prefix form: the operand is incremented or decremented before used in the expression.
     * Postfix form: the operand is incremented or decremented after used in the expression.*/
        
        
        int a=20;
        int b=30;
        
        System.out.println(++a);// Prefix
        System.out.println(a++); // Postfix
        System.out.println(a);
        
        System.out.println(--b);// Prefix
        System.out.println(b--); // Postfix
        System.out.println(b);
        
    }
}