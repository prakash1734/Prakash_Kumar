package com.hsbc.java.training.demo.Operators;
public class UnaryOperatorDemo {
    
    public static void main(String[] args) {
        
        /*+  Unary plus operator; indicates positive value (numbers are positive by default, without this operator).
        -  Unary minus operator; negate an expression.
        ++ Increment operator; increments a value by 1.
        -- Decrement operator; decrements a value by 1;
        !  Logical complement operator; inverts value of a boolean.*/
        
         int x = 5;
            int y = 10;
     
            int result = +x;
     
            System.out.println("+x = " + result);
     
            result = -y;
     
            System.out.println("-y = " + result);
     
            result = ++x;
     
            System.out.println("++x = " + result);
     
            result = --y;
     
            System.out.println("--y = " + result);
     
            boolean b = false;
     
            System.out.println(b);
     
            System.out.println(!b);
    }
}