package com.hsbc.java.training.demo.Operators;
public class RelationalOperatorDemo {
    
    public static void main(String[] args) {
        
            /*    == equal to
                != not equal to
                >  greater than
                >= greater than or equal to
                <  less than
                <= less than or equal to*/
        
         int x = 60;
            int y = 65;
     
            boolean result = x == y;
     
            System.out.println("x == y ? " + result);
     
            result = x != y;
     
            System.out.println("x != y ? " + result);
     
            result = x > y;
     
            System.out.println("x > y ? " + result);
     
            result = x >= y;
     
            System.out.println("x >= y ? " + result);
     
            result = x < y;
     
            System.out.println("x < y ? " + result);
     
            result = x <= y;
     
            System.out.println("x <= y ? " + result);
        }
    
    }