package com.hsbc.java.training.demo.Operators;
public class BitwiseOperatorDemo {
    public static void main(final String[] args) {
        /*
         * ~ unary bitwise complement; inverts a bit pattern << signed left
         * shift >> signed right shift >>> unsigned right shift & bitwise AND ^
         * bitwise exclusive OR | bitwise inclusive OR
         */
        /*
         * These operators perform bitwise and bit shift operations on only
         * integral types, not float types. They are rarely used so the listing
         * here is just for reference:
         */
        int x = 42;
        int result = x >> 2;
        // int result = x << 2;
        System.out.println("Before left shift: " + x);
        System.out.println("After left shift: " + result);
    }
}