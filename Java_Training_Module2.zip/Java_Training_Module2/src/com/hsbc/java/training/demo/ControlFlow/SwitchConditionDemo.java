package com.hsbc.java.training.demo.ControlFlow;
import java.io.IOException;
import java.util.Scanner;
public class SwitchConditionDemo {
    public static void main(final String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the days");
        int days = sc.nextInt();
        String str;
        switch (days) {
        case 1:
            str = "Sunday";
            break;
        case 2:
            str = "Monday";
            break;
        case 3:
            str = "Tuesday";
            break;
        case 4:
            str = "Wednesday";
            break;
        case 5:
            str = "thursday";
            break;
        case 6:
            str = "Friday";
            break;
        case 7:
            str = "Saturday";
            break;
        default:
            str = "Invalid Day";
        }
        sc.close();
        System.out.println(str);
    }
}