package com.hsbc.java.training.demo.Operators;
public class InstanceofOperatorDemo {
    
    public static void main(String[] args) {
        
        /* The instanceof operator tests if an object is an instance of a class, 
         * a subclass or a class that implements an interface; and result in a boolean value.
         */
        
        String city="Pune";
        
        if(city instanceof String){
            System.out.println("an instance String class");
        }
        
        // test for subclass of Object
        if (city instanceof Object) {
            System.out.println("an instance of Object class");
        }
        
     // test for subclass of an interface
        if (city instanceof CharSequence) {
            System.out.println("an instance of CharSequence interface");
        }
    }
}