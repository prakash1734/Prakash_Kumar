package com.hsbc.java.training.demo.Variables;
public class VariableDemo {
    
    // this instance variable
    int a=10;
    
    //// this static variable
    static int b=20;
    
    public void myAge(){
        
        /* age is a local variable. This is defined inside myAge() method and its scope is limited to only this method.
         *  Local variable must be initialize if not then we get CE: variable number might not have been initialized
         *  */
        int age=10;
        age=age+11;
        
        System.out.println("My Age is : "+age);
    }
    
    public static void main(String[] args) {
        
        //System.out.println(a); // this code throw exception (calling instance variable directly in static area)
        //System.out.println(b); // it's work fine
        
        
        VariableDemo ins=new VariableDemo();
        
        ins.a=88;
        ins.b=112;
        
        VariableDemo ins1=new VariableDemo();
        System.out.println(ins1.a+ "...."+ins1.b);
        
        ins.myAge();        
        
        
        
    }
}