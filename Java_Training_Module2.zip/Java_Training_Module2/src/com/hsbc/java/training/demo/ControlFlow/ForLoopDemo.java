package com.hsbc.java.training.demo.ControlFlow;
public class ForLoopDemo {
    
    public static void main(String[] args) {
        
        int i;
        int n=3;
        
        for(i=0;i<n;i++){
            
                    
            for(int j=0;j<n;j++){
            
            System.out.println("Inner for loop");
            
            }
            
            System.out.println("Outer for loop");
        }
        
        
        // for-each loop is used to traverse array or collection in java. It is easier to use than simple for loop 
        // because we don't need to increment value and use subscript notation.
        /*int array[]={8,15,23,31,39};  
        
        for(int a:array){  
            
            System.out.println(a);  */
        //}  
    }
}