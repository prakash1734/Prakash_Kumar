package com.hsbc.java.training.demo.Datatypes;
public class PrimitiveDemo {
    
    public static void main(String[] args) {
        
         byte b = 100;
            short s = 123;
            int v = 123543;
            int calc = -9876345;
            long amountVal = 1234567891;
            float intrestRate = 12.25f;
            double sineVal = 12345.234d;
            boolean flag = true;
            boolean val = false;
            char ch1 = 88; // code for X
            char ch2 = 'Y';
            System.out.println("byte Value = " + b);
            System.out.println("short Value = " + s);
            System.out.println("int Value = " + v);
            System.out.println("int second Value = " + calc);
            System.out.println("long Value = " + amountVal);
            System.out.println("float Value = " + intrestRate);
            System.out.println("double Value = " + sineVal);
            System.out.println("boolean Value = " + flag);
            System.out.println("boolean Value = " + val);
            System.out.println("char Value = " + ch1);
            System.out.println("char Value = " + ch2);
        
    }
}