package com.hsbc.java.training.demo.ControlFlow;
import java.util.Scanner;
public class IfConditionDemo {
    public static void main(final String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the age for voting");
        int age = sc.nextInt();
        if (age < 18) {
            System.out.println("Not eligible for Voting ");
        } else {
            System.out.println("Your age is : " + age + ", You are Eligible for Voting");
        }
        sc.close();
    }
}
