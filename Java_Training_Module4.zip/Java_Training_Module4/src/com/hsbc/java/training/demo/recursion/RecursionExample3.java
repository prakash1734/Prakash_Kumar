package com.hsbc.java.training.demo.recursion;

/*
 * Java Recursion Example 3: Factorial Number
 */

public class RecursionExample3 {
	static int factorial(int n) {
		if (n == 1)
			return 1;
		else
			return (n * factorial(n - 1));
	}

	public static void main(String[] args) {
		System.out.println("Factorial of 5 is: " + factorial(5));
	}
}
