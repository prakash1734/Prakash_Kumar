package com.hsbc.java.training.demo.string.stringbuffer;

/*
 * The reverse() method of StringBuilder class reverses the current string.
 */

class StringBufferExample5 {
	public static void main(String args[]) {
		StringBuffer sb = new StringBuffer("Hello");
		sb.reverse();
		System.out.println(sb);// prints olleH
	}
}
