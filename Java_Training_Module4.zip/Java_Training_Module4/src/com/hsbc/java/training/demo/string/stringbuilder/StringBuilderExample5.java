package com.hsbc.java.training.demo.string.stringbuilder;

/*
 * The reverse() method of StringBuilder class reverses the current string.
 */

class StringBuilderExample5 {
	public static void main(String args[]) {
		StringBuilder sb = new StringBuilder("Hello");
		sb.reverse();
		System.out.println(sb);// prints olleH
	}
}
