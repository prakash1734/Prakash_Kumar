package com.hsbc.java.training.demo.object;

import java.util.GregorianCalendar;

/*
 * Example of lang.Object.hashCode() method.
 */

public class ObjectDemoHashCode {

	public static void main(String[] args) {

	      // create a new ObjectDemo object
	      GregorianCalendar cal = new GregorianCalendar();

	      // print current time
	      System.out.println("" + cal.getTime());

	      // print a hashcode for cal
	      System.out.println("" + cal.hashCode());

	      // create a new Integer
	      Integer i = new Integer(5);

	      // print i
	      System.out.println("" + i);

	      // print hashcode for i
	      System.out.println("" + i.hashCode());
	   }
	}
