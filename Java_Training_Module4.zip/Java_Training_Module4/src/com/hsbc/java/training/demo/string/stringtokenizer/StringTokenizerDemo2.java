package com.hsbc.java.training.demo.string.stringtokenizer;

import java.util.StringTokenizer;

/*
 * Example of nextToken(String delim) method of StringTokenizer class
 */

public abstract class StringTokenizerDemo2 {
	public static void main(String[] args) {
		StringTokenizer st = new StringTokenizer("my,name,is,khan");

		// printing next token
		System.out.println("Next token is : " + st.nextToken(","));
	}
}
