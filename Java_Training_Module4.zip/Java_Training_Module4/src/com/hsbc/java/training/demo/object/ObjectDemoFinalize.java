package com.hsbc.java.training.demo.object;

import java.util.GregorianCalendar;

/*
 * Example of lang.Object.finalize() method.
 */

public class ObjectDemoFinalize extends GregorianCalendar  {
	public static void main(String[] args) {
		try {
			// create a new ObjectDemo object
			ObjectDemoFinalize cal = new ObjectDemoFinalize();

			// print current time
			System.out.println("" + cal.getTime());

			// finalize cal
			System.out.println("Finalizing...");
			cal.finalize();
			System.out.println("Finalized.");

		} catch (Throwable ex) {
			ex.printStackTrace();
		}
	}

}
