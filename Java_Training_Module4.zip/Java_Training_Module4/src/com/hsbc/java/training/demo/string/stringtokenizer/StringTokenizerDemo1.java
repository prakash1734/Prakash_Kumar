package com.hsbc.java.training.demo.string.stringtokenizer;

import java.util.StringTokenizer;

/*
 * Simple example of StringTokenizer class
 */

public class StringTokenizerDemo1 {

	public static void main(String args[]) {
		StringTokenizer st = new StringTokenizer("my name is khan", " ");
		while (st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
	}

}
