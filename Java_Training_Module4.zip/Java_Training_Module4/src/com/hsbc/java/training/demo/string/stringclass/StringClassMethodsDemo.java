package com.hsbc.java.training.demo.string.stringclass;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.Locale;

public class StringClassMethodsDemo {

	public static void main(String args[]) {

		String str = "ilikejava";
		/*
		 * 1 charAt(int index) Returns the char value at the specified index.
		 */
		char ch1 = str.charAt(0);
		System.out.println(ch1); // print i

		/*
		 * 2 codePointAt(int index) Returns the character (Unicode code point)
		 * at the specified index.
		 */
		int int2 = str.codePointAt(0);
		System.out.println(int2); // print ascii code of i i.e 105

		/*
		 * 3 codePointBefore(int index) Returns the character (Unicode code
		 * point) before the specified index.
		 */
		int int3 = str.codePointBefore(1);
		System.out.println(int3); // print ascii code of i i.e 105

		/*
		 * 4 codePointCount(int beginIndex, int endIndex) Returns the number of
		 * Unicode code points in the specified text range of this String.
		 */
		int int4 = str.codePointCount(0, 5);
		System.out.println(int4); // print 5

		/*
		 * 5 compareTo(String anotherString) Compares two strings
		 * lexicographically.
		 */
		int int5 = str.compareTo("ILIKEJAVA");
		System.out.println(int5); // print 32

		/*
		 * 6 compareToIgnoreCase(String str) Compares two strings
		 * lexicographically, ignoring case differences.
		 */
		int int6 = str.compareToIgnoreCase("ILIKEJAVA");
		System.out.println(int6); // print 0

		/*
		 * 7 concat(String str) Concatenates the specified string to the end of
		 * this string.
		 */
		String str2 = "technology";
		String concatstring = str.concat(str2);
		System.out.println(concatstring); // print ilikejavatechnology
		System.out.println(str); // print ilikejavatechnology

		/*
		 * 8 contains(CharSequence s) Returns true if and only if this string
		 * contains the specified sequence of char values.
		 */
		boolean isContains = str.contains("java");
		System.out.println(isContains); // print true

		/*
		 * 9 contentEquals(CharSequence cs) Compares this string to the
		 * specified CharSequence
		 */
		boolean isContentEqual = str.contains("java");
		System.out.println(isContentEqual); // print true

		/*
		 * 10 contentEquals(StringBuffer sb) Compares this string to the
		 * specified StringBuffer.
		 */
		StringBuffer sb1 = new StringBuffer("ilikejava");
		boolean isContentEqualsb1 = str.contentEquals(sb1);
		System.out.println(isContentEqualsb1); // print true

		StringBuffer sb2 = new StringBuffer("java");
		boolean isContentEqualsb2 = str.contentEquals(sb2);
		System.out.println(isContentEqualsb2); // print false

		/*
		 * 11 copyValueOf(char[] data) Returns a String that represents the
		 * character sequence in the array specified.
		 */
		char[] char11 = { 'j', 'a', 'v', 'a' };
		String str11 = String.copyValueOf(char11);
		System.out.println(str11); // print java

		/*
		 * 12 copyValueOf(char[] data, int offset, int count) Returns a String
		 * that represents the character sequence in the array specified.
		 */
		char[] char12 = { 'j', 'a', 'v', 'a' };
		String str12 = String.copyValueOf(char12, 0, 2);
		System.out.println(str12); // print ja

		/*
		 * 13 endsWith(String suffix) Tests if this string ends with the
		 * specified suffix.
		 */
		boolean isendsWithCheck = str.endsWith("a");
		System.out.println(isendsWithCheck); // print true

		/*
		 * 14 equals(Object anObject) Compares this string to the specified
		 * object.
		 */
		String str14 = "ilikejava";
		boolean isEqualCheck = str.equals(str14);
		System.out.println(isEqualCheck); // print true

		/*
		 * 15 equalsIgnoreCase(String anotherString) Compares this String to
		 * another String, ignoring case considerations.
		 */
		String str15 = "ILIKEJAVA";
		boolean isEqualIgnoreCaseCheck = str.equalsIgnoreCase(str15);
		System.out.println(isEqualIgnoreCaseCheck); // print true

		/*
		 * 16 format(Locale l, String format, Object... args) Returns a
		 * formatted string using the specified locale, format string, and
		 * arguments.
		 */
		String str16 = String.format(Locale.US, "Welcome %s !", str);
		System.out.println(str16); // print Welcome ilikejava !

		/*
		 * 17 format(String format, Object... args) Returns a formatted string
		 * using the specified format string and arguments.
		 */
		String str17 = String.format("Welcome %s !", str);
		System.out.println(str17); // print Welcome ilikejava !

		/*
		 * 18 getBytes() Encodes this String into a sequence of bytes using the
		 * platform's default charset, storing the result into a new byte array.
		 */
		byte[] byteArray18 = str.getBytes();
		System.out.println(byteArray18); // print [B@15db9742
		System.out.println(new String(byteArray18)); // print ilikejava

		/*
		 * 19 getBytes(Charset charset) Encodes this String into a sequence of
		 * bytes using the given charset, storing the result into a new byte
		 * array.
		 */
		byte[] byteArray19 = str.getBytes(Charset.forName("ASCII"));
		System.out.println(byteArray19); // print [B@6d06d69c
		System.out.println(new String(byteArray19)); // print ilikejava

		/*
		 * 20 getBytes(String charsetName) Encodes this String into a sequence
		 * of bytes using the named charset, storing the result into a new byte
		 * array.
		 */
		try {
			byte[] byteArray20 = str.getBytes("ASCII");
			System.out.println(byteArray20); // print [B@7852e922
			System.out.println(new String(byteArray20)); // print ilikejava
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		/*
		 * 21 getChars(int srcBegin, int srcEnd, char[] dst, int dstBegin)
		 * Copies characters from this string into the destination character
		 * array.
		 */
		char[] char21 = new char[5];
		str.getChars(0, 4, char21, 0);
		System.out.println(new String(char21)); // print ilik

		/*
		 * 22 hashCode() Returns a hash code for this string.
		 */
		int int22 = str.hashCode();
		System.out.println(int22); // print 299253154

		/*
		 * 23 indexOf(int ch) Returns the index within this string of the first
		 * occurrence of the specified character.
		 */
		int int23 = str.indexOf('a');
		System.out.println(int23); // print 6

		/*
		 * 24 indexOf(int ch, int fromIndex) Returns the index within this
		 * string of the first occurrence of the specified character, starting
		 * the search at the specified index.
		 */
		int int24 = str.indexOf('i', 0);
		int int24_ = str.indexOf('i', 1);
		System.out.println(int24); // print 0
		System.out.println(int24_); // print 2

		/*
		 * 25 indexOf(String str) Returns the index within this string of the
		 * first occurrence of the specified substring.
		 */
		String str25 = "hello john hello riya";
		int int25 = str25.indexOf("hello");
		System.out.println(int25); // print 0

		/*
		 * 26 indexOf(String str, int fromIndex) Returns the index within this
		 * string of the first occurrence of the specified substring, starting
		 * at the specified index.
		 */
		String str26 = "hello john hello riya";
		int int26 = str26.indexOf("hello", 1); // print 11
		System.out.println(int26);

		/*
		 * 27 intern() Returns a canonical representation for the string object.
		 */
		String s1 = new String("hello");
		String s2 = "hello";
		String s3 = s1.intern();// returns string from pool, now it will be same
								// as s2
		System.out.println(s1 == s2);// false because reference is different
		System.out.println(s2 == s3);// true because reference is same

		/*
		 * 28 isEmpty() Returns true if, and only if, length() is 0.
		 */
		String str28 = "";
		boolean isEmptyCheck = str28.isEmpty();
		System.out.println(isEmptyCheck); // print true

		/*
		 * 29 lastIndexOf(int ch) Returns the index within this string of the
		 * last occurrence of the specified character.
		 */
		int int29 = str.lastIndexOf('a');
		System.out.println(int29); // print 8

		/*
		 * 30 lastIndexOf(int ch, int fromIndex) Returns the index within this
		 * string of the last occurrence of the specified character, searching
		 * backward starting at the specified index.
		 */
		int int30 = str.lastIndexOf('i', 2);
		System.out.println(int30); // print 2

		/*
		 * 31 lastIndexOf(String str) Returns the index within this string of
		 * the last occurrence of the specified substring.
		 */
		String str31 = "hello john hello riya";
		int int31 = str31.lastIndexOf("hello");
		System.out.println(int31); // print 11

		/*
		 * 32 lastIndexOf(String str, int fromIndex) Returns the index within
		 * this string of the last occurrence of the specified substring,
		 * searching backward starting at the specified index.
		 */
		String str32 = "hello john hello riya";
		int int32 = str32.lastIndexOf("hello", 10);
		System.out.println(int32); // print 0

		/*
		 * 33 length() Returns the length of this string.
		 */
		int int33 = str.length();
		System.out.println(int33); // print 9

		/*
		 * 34 matches(String regex) Tells whether or not this string matches the
		 * given regular expression.
		 */
		String Str = new String("Welcome to Tutorialspoint.com");
		System.out.println(Str.matches("(.*)Tutorials(.*)")); // print true
		System.out.println(Str.matches("Tutorials")); // print false

		/*
		 * 35 offsetByCodePoints(int index, int codePointOffset) Returns the
		 * index within this String that is offset from the given index by
		 * codePointOffset code points.
		 */
		String str35 = "aacdefaa";
		// returns the index within this String
		int retval = str35.offsetByCodePoints(2, 4);
		// prints the index
		System.out.println("index = " + retval); // print index=6

		/*
		 * 36 regionMatches(boolean ignoreCase, int toffset, String other, int
		 * ooffset, int len) Tests if two string regions are equal.
		 */
		String Str36_1 = new String("Welcome to Java");
		String Str36_2 = new String("JAVA");
		System.out.println(Str36_1.regionMatches(false, 11, Str36_2, 0, 4)); // print
																				// false
		System.out.println(Str36_1.regionMatches(true, 11, Str36_2, 0, 4)); // print
																			// true

		/*
		 * 37 regionMatches(int toffset, String other, int ooffset, int len)
		 * Tests if two string regions are equal.
		 */
		String Str37_1 = new String("Welcome to Java");
		String Str37_2 = new String("JAVA");
		System.out.println(Str37_1.regionMatches(11, Str37_2, 0, 4)); // print
																		// false

		/*
		 * 38 replace(char oldChar, char newChar) Returns a new string resulting
		 * from replacing all occurrences of oldChar in this string with
		 * newChar.
		 */
		String str38_old = "Hello Java Learners";
		String str38_new = str38_old.replace('e', 'E');
		System.out.println(str38_new); // print HEllo Java LEarnErs

		/*
		 * 39 replace(CharSequence target, CharSequence replacement) Replaces
		 * each substring of this string that matches the literal target
		 * sequence with the specified literal replacement sequence.
		 */
		String str39_old = "Hello Java Learners";
		CharSequence oldCharSeq = "Jav";
		CharSequence newCharSeq = "JAV";
		String str39_new = str39_old.replace(oldCharSeq, newCharSeq);
		System.out.println(str39_new); // print Hello JAVa Learners

		/*
		 * 40 replaceAll(String regex, String replacement) Replaces each
		 * substring of this string that matches the given regular expression
		 * with the given replacement.
		 */
		String str40_old = "Hello Java Learners";
		String str40_new = str40_old.replace("Java", "Python");
		System.out.println(str40_new); // print Hello Python Learners

		/*
		 * 41 replaceFirst(String regex, String replacement) Replaces the first
		 * substring of this string that matches the given regular expression
		 * with the given replacement.
		 */
		String str41_old = "Welcome to example.com";
		String str41_new = str41_old.replaceFirst("(.*)example(.*)", "java"); // print
																				// java
		System.out.println(str41_new);
		System.out.println(str41_old.replaceFirst("example", "java")); // print
																		// Welcome
																		// to
																		// java.com

		/*
		 * 42 split(String regex) Splits this string around matches of the given
		 * regular expression.
		 */
		String phone = "012-3456789";
		String[] output = phone.split("-");
		System.out.println(output[0]); // print 012
		System.out.println(output[1]); // print 3456789

		/*
		 * 43 split(String regex, int limit) Splits this string around matches
		 * of the given regular expression.
		 */
		String str43 = "Welcome-to-java.com";
		String[] output43 = str43.split("-", 2);

		for (String s : output43) {
			System.out.println(s);
		}
		// print following
		// Welcome
		// to-java.com

		String[] output43_2 = str43.split("-", 3);

		for (String s : output43_2) {
			System.out.println(s);
		}
		// print following
		// Welcome
		// to
		// java.com

		/*
		 * 44 startsWith(String prefix) Tests if this string starts with the
		 * specified prefix.
		 */
		String str44 = new String("Welcome to geeksforgeeks");

		// Testing the prefix using startsWith()
		System.out.print("Check whether string starts with Welcome : ");
		System.out.println(str44.startsWith("Welcome")); // print true

		// Testing the prefix using startsWith()
		System.out.print("Check whether string starts with geeks : ");
		System.out.println(str44.startsWith("geeks")); // print false

		/*
		 * 45 startsWith(String prefix, int toffset) Tests if the substring of
		 * this string beginning at the specified index starts with the
		 * specified prefix.
		 */
		String str45 = new String("Welcome to geeksforgeeks");

		// Testing the prefix using startsWith()
		System.out.print("Check whether string starts with Welcome at pos 11 : ");
		System.out.println(str45.startsWith("Welcome", 11)); // print false

		// Testing the prefix using startsWith()
		System.out.print("Check whether string starts with geeks at pos 11 : ");
		System.out.println(str45.startsWith("geeks", 11)); // print true

		/*
		 * 46 subSequence(int beginIndex, int endIndex) Returns a new character
		 * sequence that is a subsequence of this sequence.
		 */
		String str46 = new String("Welcome to Tutorialspoint.com");
		CharSequence charSeq46_1 = str46.subSequence(0, 10);
		CharSequence charSeq46_2 = str46.subSequence(10, 15);
		System.out.println(charSeq46_1); // print Welcome to
		System.out.println(charSeq46_2); // print Tuto

		/*
		 * 47 substring(int beginIndex) Returns a new string that is a substring
		 * of this string.
		 */
		String str47 = "helloworldjava";
		String substr47 = str47.substring(2);
		System.out.println(substr47); // print lloworldjava

		/*
		 * 48 substring(int beginIndex, int endIndex) Returns a new string that
		 * is a substring of this string.
		 */
		String str48 = "helloworldjava";
		String substr48 = str48.substring(2, 10);
		System.out.println(substr48); // print lloworld

		/*
		 * 49 toCharArray() Converts this string to a new character array.
		 */
		String str49 = "hello";
		char[] ch49 = str49.toCharArray();
		for (int i = 0; i < ch49.length; i++) {
			System.out.print(ch49[i]);
		} // print hello

		/*
		 * 50 toLowerCase() Converts all of the characters in this String to
		 * lower case using the rules of the default locale.
		 */
		String str50 = "JAVATPOINT HELLO stRIng";
		String str50lower = str50.toLowerCase();
		System.out.println(str50lower); // print hellojavatpoint hello string

		/*
		 * 51 toLowerCase(Locale locale) Converts all of the characters in this
		 * String to lower case using the rules of the given Locale.
		 */
		String str51 = "Self Learning Center";

		// using the default system Locale
		Locale defloc = Locale.getDefault();
		String str51lower = str51.toLowerCase(defloc);
		System.out.println(str51lower); // print self learning center

		/*
		 * 52 toString() This object (which is already a string!) is itself
		 * returned.
		 */
		String str52 = new String("Welcome to Java Learning");
		String str52toString = str52.toString();
		System.out.println(str52toString); // print Welcome to Java Learning

		/*
		 * 53 toUpperCase() Converts all of the characters in this String to
		 * upper case using the rules of the default locale.
		 */
		String str53 = "Hello Java Learners";
		String str53upper = str53.toUpperCase();
		System.out.println(str53upper); // print HELLO JAVA LEARNERS

		/*
		 * 54 toUpperCase(Locale locale) Converts all of the characters in this
		 * String to upper case using the rules of the given Locale.
		 */
		String str54 = "Self Learning Center";

		// using the default system Locale
		Locale defloc54 = Locale.getDefault();
		String str54upper = str54.toUpperCase(defloc54);
		System.out.println(str54upper); // print SELF LEARNING CENTER

		/*
		 * 55 trim() Returns a copy of the string, with leading and trailing
		 * whitespace omitted.
		 */
		String str55 = "  hello string   ";
		// without trim() print hello string javatrimexample
		System.out.println(str55 + "javatrimexample");
		// with trim() hello stringjavatrimexample
		System.out.println(str55.trim() + "javatrimexample");

		/*
		 * 56 valueOf(boolean b) Returns the string representation of the
		 * boolean argument.
		 */
		String str56_1 = String.valueOf(true);
		String str56_2 = String.valueOf(false);

		// print the string representation of boolean
		System.out.println(str56_1); // print true
		System.out.println(str56_2); // print false

		/*
		 * 57 valueOf(char c) Returns the string representation of the char
		 * argument.
		 */
		char char57 = 'Z';
		String str57 = String.valueOf(char57);
		System.out.println(str57); // print Z

		/*
		 * 58 valueOf(char[] data) Returns the string representation of the char
		 * array argument.
		 */
		char[] chararr58 = new char[] { 'j', 'a', 'v', 'a' };
		String str58 = String.valueOf(chararr58);
		System.out.println(str58); // print java

		/*
		 * 59 valueOf(char[] data, int offset, int count) Returns the string
		 * representation of a specific subarray of the char array argument.
		 */
		char[] chararr59 = new char[] { 'j', 'a', 'v', 'a' };
		String str59 = String.valueOf(chararr59, 0, 2);
		System.out.println(str59); // print ja

		/*
		 * 60 valueOf(double d) Returns the string representation of the double
		 * argument.
		 */
		String str60_1 = String.valueOf(12.97);
		String str60_2 = String.valueOf(Double.MIN_VALUE);
		String str60_3 = String.valueOf(Double.MAX_VALUE);

		// print the string representation of double
		System.out.println(str60_1); // print 12.97
		System.out.println(str60_2); // print 4.9E-324
		System.out.println(str60_3); // print 1.7976931348623157E308

		/*
		 * 61 valueOf(float f) Returns the string representation of the float
		 * argument.
		 */
		String str61_1 = String.valueOf(12.85f);
		String str61_2 = String.valueOf(Float.MIN_VALUE);
		String str61_3 = String.valueOf(Float.MAX_VALUE);

		// prints the string representations of float
		System.out.println(str61_1); // print 12.85
		System.out.println(str61_2); // print 1.4E-45
		System.out.println(str61_3); // print 3.4028235E38

		/*
		 * 62 valueOf(int i) Returns the string representation of the int
		 * argument.
		 */
		int value = 30;
		String str62 = String.valueOf(value);
		System.out.println(str62 + 10);// concatenating happens. Print 3010

		/*
		 * 63 valueOf(long l) Returns the string representation of the long
		 * argument.
		 */
		String str63_1 = String.valueOf(432567);
		String str63_2 = String.valueOf(Long.MIN_VALUE);
		String str63_3 = String.valueOf(Long.MAX_VALUE);

		// prints the string representations of long
		System.out.println(str63_1); // print 432567
		System.out.println(str63_2); // print -9223372036854775808
		System.out.println(str63_3); // print 9223372036854775807

		/*
		 * 64 valueOf(Object obj) Returns the string representation of the
		 * Object argument.
		 */
		String str64 = "compile online";
		Object objVal = str64;

		// returns the string representation of the Object argument
		System.out.println(String.valueOf(objVal)); //print compile online

	}

}
