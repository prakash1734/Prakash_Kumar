package com.hsbc.java.training.demo.characterstream.FileWriter;

import java.io.FileWriter;

/*
 * Java FileWriter Example
 * In this example, we are writing the data in the file testout.txt using Java FileWriter class.
 */
public class FileWriterExample {

	public static void main(String args[]) {
		try {
			FileWriter fw = new FileWriter("C:\\Training\\FileWriter\\testout.txt");
			fw.write("Welcome to javaTpoint.");
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Success...");
	}

}
