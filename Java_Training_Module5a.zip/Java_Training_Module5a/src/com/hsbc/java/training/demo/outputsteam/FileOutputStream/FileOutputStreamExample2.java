package com.hsbc.java.training.demo.outputsteam.FileOutputStream;

import java.io.FileOutputStream;

/*
 * Java FileOutputStream example 2: write string 
 */

public class FileOutputStreamExample2 {
	public static void main(String args[]) {
		try {
			FileOutputStream fout = new FileOutputStream("C:\\Training\\FileOutputStream\\testout2.txt");
			String s = "Welcome to javaTpoint.";
			byte b[] = s.getBytes();// converting string into byte array
			fout.write(b);
			fout.close();
			System.out.println("success...");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
