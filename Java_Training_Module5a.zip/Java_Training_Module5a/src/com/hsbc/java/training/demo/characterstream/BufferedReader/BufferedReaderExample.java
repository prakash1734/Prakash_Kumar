package com.hsbc.java.training.demo.characterstream.BufferedReader;

import java.io.BufferedReader;
import java.io.FileReader;

/*
 * Java BufferedReader Example
 * In this example, we are reading the data from the text file testout.txt using Java BufferedReader class.
 */
public class BufferedReaderExample {

	public static void main(String args[]) throws Exception {
		FileReader fr = new FileReader("C:\\Training\\BufferedReader\\testout.txt");
		BufferedReader br = new BufferedReader(fr);

		int i;
		while ((i = br.read()) != -1) {
			System.out.print((char) i);
		}
		br.close();
		fr.close();
	}

}
