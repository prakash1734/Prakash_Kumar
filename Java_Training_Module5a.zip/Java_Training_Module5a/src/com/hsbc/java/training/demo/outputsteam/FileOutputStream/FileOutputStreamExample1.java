package com.hsbc.java.training.demo.outputsteam.FileOutputStream;

/*
 * Java FileOutputStream Example 1: write byte
 */
import java.io.FileOutputStream;

public class FileOutputStreamExample1 {
	public static void main(String args[]) {
		try {
			FileOutputStream fout = new FileOutputStream("C:\\Training\\FileOutputStream\\testout1.txt");
			fout.write(65);
			fout.close();
			System.out.println("success...");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
