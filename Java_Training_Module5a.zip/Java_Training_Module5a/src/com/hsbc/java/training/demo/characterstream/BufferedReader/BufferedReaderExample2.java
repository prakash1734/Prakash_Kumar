package com.hsbc.java.training.demo.characterstream.BufferedReader;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/*
 * Reading data from console by InputStreamReader and BufferedReader
 * In this example, we are connecting the BufferedReader stream with the InputStreamReader stream for reading the line by line data from the keyboard.
 */
public class BufferedReaderExample2 {

	public static void main(String args[]) throws Exception {
		InputStreamReader r = new InputStreamReader(System.in);
		BufferedReader br = new BufferedReader(r);
		System.out.println("Enter your name");
		String name = br.readLine();
		System.out.println("Welcome " + name);
	}

}
