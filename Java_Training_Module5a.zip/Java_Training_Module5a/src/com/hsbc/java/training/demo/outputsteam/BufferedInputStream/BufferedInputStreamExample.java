package com.hsbc.java.training.demo.outputsteam.BufferedInputStream;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

/*
 * Example of BufferedInputStream class
 */

public class BufferedInputStreamExample {
	public static void main(String args[]) {
		try {
			FileInputStream fin = new FileInputStream("C:\\Training\\BufferedInputStream\\testout1.txt");
			BufferedInputStream bin = new BufferedInputStream(fin);
			int i;
			while ((i = bin.read()) != -1) {
				System.out.print((char) i);
			}
			bin.close();
			fin.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
