package com.hsbc.java.training.demo.characterstream.BufferedWriter;

import java.io.BufferedWriter;
import java.io.FileWriter;

/*
 * Example of Java BufferedWriter
 * Let's see the simple example of writing the data to a text file testout.txt using Java BufferedWriter.
 */
public class BufferedWriterExample {

	public static void main(String[] args) throws Exception {
		FileWriter writer = new FileWriter("C:\\Training\\BufferedWriter\\testout.txt");
		BufferedWriter buffer = new BufferedWriter(writer);
		buffer.write("Welcome to javaTpoint.");
		buffer.close();
		System.out.println("Success");
	}

}
