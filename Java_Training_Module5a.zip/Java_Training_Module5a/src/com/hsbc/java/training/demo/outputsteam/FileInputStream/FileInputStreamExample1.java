package com.hsbc.java.training.demo.outputsteam.FileInputStream;

import java.io.FileInputStream;

/*
 * Java FileInputStream example 1: read single character
 */

public class FileInputStreamExample1 {
	public static void main(String args[]) {
		try {
			FileInputStream fin = new FileInputStream("C:\\Training\\FileInputStream\\testout1.txt");
			int i = fin.read();
			System.out.print((char) i);

			fin.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
