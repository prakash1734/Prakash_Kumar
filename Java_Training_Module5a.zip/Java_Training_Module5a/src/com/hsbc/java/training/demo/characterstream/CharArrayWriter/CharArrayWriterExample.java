package com.hsbc.java.training.demo.characterstream.CharArrayWriter;

import java.io.CharArrayWriter;
import java.io.FileWriter;

/*
 * Example of CharArrayWriter Class:
 * In this example, we are writing a common data to 4 files a.txt, b.txt, c.txt and d.txt.
 */
public class CharArrayWriterExample {

	public static void main(String args[]) throws Exception {
		CharArrayWriter out = new CharArrayWriter();
		out.write("Welcome to javaTpoint");
		FileWriter f1 = new FileWriter("C:\\Training\\CharArrayWriter\\a.txt");
		FileWriter f2 = new FileWriter("C:\\Training\\CharArrayWriter\\b.txt");
		FileWriter f3 = new FileWriter("C:\\Training\\CharArrayWriter\\c.txt");
		FileWriter f4 = new FileWriter("C:\\Training\\CharArrayWriter\\d.txt");
		out.writeTo(f1);
		out.writeTo(f2);
		out.writeTo(f3);
		out.writeTo(f4);
		f1.close();
		f2.close();
		f3.close();
		f4.close();
		System.out.println("Success...");
	}

}
