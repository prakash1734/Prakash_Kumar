package com.hsbc.java.training.demo.outputsteam.DataOutputStream;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/*
 * Example of DataOutputStream class
 * In this example, we are writing the data to a text file testout.txt using DataOutputStream class.
 */

public class DataOutputStreamExample {

	public static void main(String[] args) throws IOException {  
        FileOutputStream file = new FileOutputStream("C:\\Training\\DataOutputStream\\testout.txt");  
        DataOutputStream data = new DataOutputStream(file);  
        data.writeInt(65);  
        data.flush();  
        data.close();  
        System.out.println("Succcess...");  
    }

}
