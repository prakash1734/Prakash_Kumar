package com.hsbc.java.training.demo.characterstream.Writer;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

/*
 * Java Writer Example
 */
public class WriterExample {

	public static void main(String[] args) {
		try {
			Writer w = new FileWriter("C:\\Training\\Writer\\output.txt");
			String content = "I love my country";
			w.write(content);
			w.close();
			System.out.println("Done");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
