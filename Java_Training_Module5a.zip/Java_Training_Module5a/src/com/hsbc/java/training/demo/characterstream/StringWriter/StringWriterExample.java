package com.hsbc.java.training.demo.characterstream.StringWriter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;

/*
 * Java StringWriter Example
 * Let's see the simple example of StringWriter using BufferedReader to read file data from the stream.
 */
public class StringWriterExample {

	public static void main(String[] args) throws IOException {
		char[] ary = new char[512];
		StringWriter writer = new StringWriter();
		FileInputStream input = null;
		BufferedReader buffer = null;
		input = new FileInputStream("C:\\Training\\StringWriter\\testout.txt");
		buffer = new BufferedReader(new InputStreamReader(input, "UTF-8"));
		int x;
		while ((x = buffer.read(ary)) != -1) {
			writer.write(ary, 0, x);
		}
		System.out.println(writer.toString());
		writer.close();
		buffer.close();
	}

}
