package com.hsbc.java.training.demo.collectionframework.collection;

import java.util.*;

/*
 * Example of Collection Interface
 */
public class CollectionsDemo2 {

	public static void main(String[] args) {
		// ArrayList
		Collection<String> a1 = new ArrayList<String>();
		a1.add("Zara");
		a1.add("Mahnaz");
		a1.add("Ayan");
		System.out.println(" ArrayList Elements");
		System.out.print("\t" + a1);

		// LinkedList
		Collection<String> l1 = new LinkedList<String>();
		l1.add("Zara");
		l1.add("Mahnaz");
		l1.add("Ayan");
		System.out.println();
		System.out.println(" LinkedList Elements");
		System.out.print("\t" + l1);

		// HashSet
		Collection<String> s1 = new HashSet<String>();
		s1.add("Zara");
		s1.add("Mahnaz");
		s1.add("Ayan");
		System.out.println();
		System.out.println(" Set Elements");
		System.out.print("\t" + s1);

	}
}
