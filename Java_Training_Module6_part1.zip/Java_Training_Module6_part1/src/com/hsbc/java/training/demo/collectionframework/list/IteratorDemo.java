package com.hsbc.java.training.demo.collectionframework.list;

/*
 * Java program to demonstrate Iterator
 */
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IteratorDemo {
	public static void main(String[] args) {
		List<Integer> al = new ArrayList<Integer>();

		for (int i = 0; i < 10; i++)
			al.add(i);

		System.out.println(al);

		// at beginning itr(cursor) will point to
		// index just before the first element in al
		Iterator<Integer> itr = al.iterator();

		// checking the next element availability
		while (itr.hasNext()) {
			// moving cursor to next element
			int i = itr.next();

			// getting even elements one by one
			System.out.print(i + " ");

			// Removing odd elements
			if (i % 2 != 0)
				itr.remove();
		}
		System.out.println();
		System.out.println(al);
	}
}
