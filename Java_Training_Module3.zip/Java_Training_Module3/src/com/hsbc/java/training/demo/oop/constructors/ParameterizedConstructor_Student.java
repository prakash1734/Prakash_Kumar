package com.hsbc.java.training.demo.oop.constructors;
public class ParameterizedConstructor_Student {
    
    int id;
    String name;
    ParameterizedConstructor_Student(final int i, final String n) {
        this.id = i;
        this.name = n;
    }
    void display() {
        System.out.println(this.id + " " + this.name);
    }
    public static void main(final String[] args) {
        ParameterizedConstructor_Student s1 = new ParameterizedConstructor_Student(111, "Prakash");
        ParameterizedConstructor_Student s2 = new ParameterizedConstructor_Student(222, "Aaditya");
        s1.display();
        s2.display();
    }
}