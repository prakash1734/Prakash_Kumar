package com.hsbc.java.training.demo.oop.binding;

//Example of Dynamic Binding
class Dog2 extends Animal2 {

    public static void main(String args[]) {

        Animal2 a = new Dog2();
        a.eat(); // prints >> dog is eating...

    }

    public void eat() {
        System.out.println("dog is eating...");
    }
}