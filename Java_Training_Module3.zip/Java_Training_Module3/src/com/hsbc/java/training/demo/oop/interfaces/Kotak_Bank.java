package com.hsbc.java.training.demo.oop.interfaces;

public class Kotak_Bank implements Bank{
    
    public float rateOfInterest()
    {
        return 6.10f;
    }  
}
