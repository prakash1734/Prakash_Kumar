package com.hsbc.java.training.demo.oop.polymorphism.overriding;

public class Cat extends Animal_OverridingExample {
    public void sound() {
        System.out.println("Meow");
    }
}
