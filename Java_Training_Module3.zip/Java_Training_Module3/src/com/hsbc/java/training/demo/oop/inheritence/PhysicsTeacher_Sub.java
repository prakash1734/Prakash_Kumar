package com.hsbc.java.training.demo.oop.inheritence;

public class PhysicsTeacher_Sub extends Teacher_P{
    
    /*IS-A relation : PhysicsTeacher IS-A Teacher.
    This means that a  child class has IS-A relationship with the parent class. This is inheritance is known as IS-A 
    relationship between child and parent class*/
    
    String mainSubject = "Physics";
    
       public static void main(String args[]){
           
        PhysicsTeacher_Sub obj = new PhysicsTeacher_Sub();
        System.out.println(obj.CollegeName);
        System.out.println(obj.designation);
        System.out.println(obj.mainSubject);
        obj.does();
       }
    }
