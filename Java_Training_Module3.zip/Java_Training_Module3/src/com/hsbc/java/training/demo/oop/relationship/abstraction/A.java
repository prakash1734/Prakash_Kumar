package com.hsbc.java.training.demo.oop.relationship.abstraction;

public interface A {

}
