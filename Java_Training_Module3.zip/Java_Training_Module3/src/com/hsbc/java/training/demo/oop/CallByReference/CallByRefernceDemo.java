package com.hsbc.java.training.demo.oop.CallByReference;
public class CallByRefernceDemo {
    
    int data=400;
    
    void change(CallByRefernceDemo op)
    {  
        //changes will be in the instance variable  
         op.data=op.data+100;
         }  
             
            
         public static void main(String args[]){  
           CallByRefernceDemo op=new CallByRefernceDemo();  
          
           System.out.println("before change "+op.data);  
           op.change(op);//passing object  
           System.out.println("after change "+op.data);  
          
         }  
}