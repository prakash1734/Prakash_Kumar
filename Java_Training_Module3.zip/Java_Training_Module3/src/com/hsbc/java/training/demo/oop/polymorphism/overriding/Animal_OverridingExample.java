package com.hsbc.java.training.demo.oop.polymorphism.overriding;

public class Animal_OverridingExample {
    
    
    public void sound(){
          System.out.println("Animal is making a sound");
    }    
}
