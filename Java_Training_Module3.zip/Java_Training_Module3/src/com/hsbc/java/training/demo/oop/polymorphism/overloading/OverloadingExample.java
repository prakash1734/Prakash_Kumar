package com.hsbc.java.training.demo.oop.polymorphism.overloading;

public class OverloadingExample {
    public void show(int a, int b) {
        System.out.println("Show Mehtod 1");
    }
    // Both methods are having same number, data types and same sequence of data
    // types.
    /*
     * public void show(int val1,int val2){
     * 
     * System.out.println("Compile time error. Argument lists are exactly same."
     * ); }
     */
    public void show(int x, double y) {
        System.out.println("Show Method 2");
    }
    public void show(char c, float f, int a) {
        System.out.println("Show Method 3");
    }
    public static void main(String[] args) {
        OverloadingExample obj = new OverloadingExample();
        obj.show(10, 20.6);
        obj.show(40,70);
        obj.show('a', 205.23f, 20);
    }
}
