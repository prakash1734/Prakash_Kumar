package com.hsbc.java.training.demo.oop.binding;

class Animal2 {

    public void eat() {
        System.out.println("Inside eat method of Animal");
    }
}

