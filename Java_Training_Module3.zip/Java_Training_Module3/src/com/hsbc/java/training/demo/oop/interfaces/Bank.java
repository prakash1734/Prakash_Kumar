package com.hsbc.java.training.demo.oop.interfaces;

public interface Bank {

    float rateOfInterest(); 
}
