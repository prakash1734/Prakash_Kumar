package com.hsbc.java.training.demo.oop.relationship.composition;

//class book
class Book 
{

 public String title;
 public String author;
  
 Book(String title, String author)
 {
      
     this.title = title;
     this.author = author;
 }
}

