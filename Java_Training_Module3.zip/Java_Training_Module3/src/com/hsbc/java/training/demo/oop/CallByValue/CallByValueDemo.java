package com.hsbc.java.training.demo.oop.CallByValue;
public class CallByValueDemo {
    int value = 100;
    public void change(int value) {
        // changes will be in the local variable only
        value = value + 50;
    }
    public static void main(String[] args) {
        CallByValueDemo obj = new CallByValueDemo();
        System.out.println("Before changes: " + obj.value);
        obj.change(200);
        System.out.println("After Changes: " + obj.value);
    }
}