package com.hsbc.java.training.demo.oop.relationship.association;

// class bank
class Bank 
{
    private String name;
     
    // bank name
    Bank(String name)
    {
        this.name = name;
    }
     
    public String getBankName()
    {
        return this.name;
    }
} 