package com.hsbc.java.training.demo.oop.interfaces;

public class Canara_Bank implements Bank {
    
    public float rateOfInterest()
    {
        return 6.15f;
    }  
}
