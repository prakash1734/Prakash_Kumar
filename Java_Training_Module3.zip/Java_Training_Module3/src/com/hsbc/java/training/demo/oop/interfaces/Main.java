package com.hsbc.java.training.demo.oop.interfaces;

public class Main {
    
    public static void main(String[] args) {
        
        //Bank b=new Canara_Bank(); 
        Bank b=new Kotak_Bank(); 
        
        System.out.println("Rate Of Interest: "+b.rateOfInterest());  
    }
    
}
