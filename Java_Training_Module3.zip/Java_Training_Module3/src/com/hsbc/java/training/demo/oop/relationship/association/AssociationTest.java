package com.hsbc.java.training.demo.oop.relationship.association;

// Association between both the 
// classes in main method
class AssociationTest 
{
    public static void main (String[] args) 
    {
        Bank bank = new Bank("Axis");
        Employee emp = new Employee("Neha");
         
        System.out.println(emp.getEmployeeName() + 
               " is employee of " + bank.getBankName());
    }
}