package com.hsbc.java.training.demo.oop.constructors;

public class DefaultConstuctor_Student {
    int id;
    String name;
    void display() {
        System.out.println(this.id + " " + this.name);
    }
    public static void main(final String[] args) {
        DefaultConstuctor_Student s1 = new DefaultConstuctor_Student();
        DefaultConstuctor_Student s2 = new DefaultConstuctor_Student();
        s1.display();
        s2.display();
    }
}