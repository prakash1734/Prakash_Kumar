package com.hsbc.java.training.demo.oop.encapsulation;

public class EncapsulationMain {

	public static void main(String[] args) {

		EncapsulationExample encap = new EncapsulationExample();

		encap.setEmpId(10);
		encap.setEmpName("Prakash");
		encap.setEmpSal(200000);

		System.out.println("Employee Id : " + encap.getEmpId());
		System.out.println("Employee Name : " + encap.getEmpName());

		encap.deposit(1100);
		// encap.withdraw(3000);

		System.out.println("Direct Accessing Employee Age :" + encap.age);

	}
}
