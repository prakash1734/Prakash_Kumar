package com.hsbc.java.training.demo.oop.inheritence;

public class RelationsDemo {
    public static void main(String[] args) {          
        Maruti myMaruti = new Maruti();  
        myMaruti.setColor("BLUE");  
        myMaruti.setMaxSpeed(200);  
        myMaruti.carInfo();  
        myMaruti.MarutiStartDemo();  
    }
}
