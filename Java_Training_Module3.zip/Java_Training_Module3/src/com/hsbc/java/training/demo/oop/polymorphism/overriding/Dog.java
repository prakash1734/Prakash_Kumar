package com.hsbc.java.training.demo.oop.polymorphism.overriding;

public class Dog extends Animal_OverridingExample{
    
    public void sound(){
        
        System.out.println("Bark");
    }
}
