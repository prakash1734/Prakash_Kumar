package com.hsbc.java.training.demo.oop.inheritence;

public class Teacher_P {
    
    String designation="Teacher";
    String CollegeName="Pune College";
    
    void does(){
        
        System.out.println("Teaching");
    }
}
