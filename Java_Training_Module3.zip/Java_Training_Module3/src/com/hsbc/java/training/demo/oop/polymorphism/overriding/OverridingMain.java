package com.hsbc.java.training.demo.oop.polymorphism.overriding;

public class OverridingMain {
    
    public static void main(String[] args) {
        
        Animal_OverridingExample obj1=new Cat();
        obj1.sound();
        
        Animal_OverridingExample obj2=new Dog();
        obj2.sound();
        
    }
}
