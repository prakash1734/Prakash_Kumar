package com.hsbc.java.training.demo.oop.encapsulation;

public class EncapsulationExample {
	private int empId;

	private String empName;

	private double empSal;

	int age;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;

	}

	public double getEmpSal() {
		return empSal;
	}

	public void setEmpSal(double empSal) {

		this.empSal = empSal;
	}

	public void deposit(int i) {

		if (i < 0) {
			System.out.println("Invalid deposit Amount");

		} else
			empSal = empSal + i;
		System.out.println("Current Balance : " + empSal);
	}

	public void withdraw(int i) {
		if (i > empSal) {

			System.out.println("Not enough balance to process");
		} else {
			empSal = empSal - i;
			System.out.println("Account Balance is : " + empSal);
		}

	}
}
