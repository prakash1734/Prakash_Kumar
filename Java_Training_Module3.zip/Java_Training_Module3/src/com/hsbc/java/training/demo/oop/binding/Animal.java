package com.hsbc.java.training.demo.oop.binding;

class Animal {
    static void eat() {
        System.out.println("animal is eating...");
    }
}

