package com.hsbc.java.training.demo.collectionframework.list.linkedlist.initialization;

/*
 * Method3: Normal way of LinkedList initialization
 */
import java.util.*;

public class LinkedListInitializationExample3 {
	public static void main(String args[]) {
		LinkedList<String> books = new LinkedList<String>();
		books.add("Java Book1");
		books.add("Java Book2");
		books.add("Java Book3");
		System.out.println("Books stored in linked list are: " + books);
	}
}
