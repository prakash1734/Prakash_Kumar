package com.hsbc.java.training.demo.collectionframework.list.arraylist.initialization;

/*
 * Method 1: Initialization using Arrays.asList
 */
import java.util.*;

public class ArrayListInitializationExample1 {
	public static void main(String args[]) {
		ArrayList<String> obj = new ArrayList<String>(Arrays.asList("Pratap", "Peter", "Harsh"));
		System.out.println("Elements are:" + obj);
	}
}
