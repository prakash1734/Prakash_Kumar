package com.hsbc.java.training.demo.collectionframework.set.hashset;
/*
 * Iterate over a Set/HashSet using Iterator
 */
import java.util.HashSet;
import java.util.Iterator;

class IterateHashSet{ 
  public static void main(String[] args) {
     // Create a HashSet
     HashSet<String> hset = new HashSet<String>();
 
     //add elements to HashSet
     hset.add("Chaitanya");
     hset.add("Rahul");
     hset.add("Tim");
     hset.add("Rick");
     hset.add("Harry");
 
     Iterator<String> it = hset.iterator();
     while(it.hasNext()){
        System.out.println(it.next());
     }
  }
}
