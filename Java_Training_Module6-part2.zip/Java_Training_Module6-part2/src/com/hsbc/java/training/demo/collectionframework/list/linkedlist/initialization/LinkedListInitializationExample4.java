package com.hsbc.java.training.demo.collectionframework.list.linkedlist.initialization;

/*
 * Method 4: Use Collections.ncopies
 */
import java.util.*;

public class LinkedListInitializationExample4 {
   public static void main(String args[]) {
	   LinkedList<Integer> intlist = new LinkedList<Integer>(Collections.nCopies(10, 5));
	  System.out.println("LinkedList items: "+intlist);
   }
}
