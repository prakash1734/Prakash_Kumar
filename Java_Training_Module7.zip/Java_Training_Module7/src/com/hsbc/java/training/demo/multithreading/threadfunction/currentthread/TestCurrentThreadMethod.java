package com.hsbc.java.training.demo.multithreading.threadfunction.currentthread;
/*
 * The currentThread() method

 */
class TestCurrentThreadMethod extends Thread {
	public void run() {
		System.out.println(Thread.currentThread().getName());
	}

	public static void main(String args[]) {
		TestCurrentThreadMethod t1 = new TestCurrentThreadMethod();
		TestCurrentThreadMethod t2 = new TestCurrentThreadMethod();

		t1.start();
		t2.start();
	}
}
