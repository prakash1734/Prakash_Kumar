package com.hsbc.java.training.demo.multithreading.threadcreation.runnable;

/*
 * Thread creation by Implementing the Runnable Interface
 */
class MyThread implements Runnable
{
 public void run()
 {
  System.out.println("concurrent thread started running..");
 }
}

class MyThreadRunnableDemo1
{
 public static void main( String args[] )
 {
  MyThread mt = new MyThread();
  Thread t = new Thread(mt);
  t.start();
 }
}

