package com.hsbc.java.training.demo.multithreading.threadcreation.thread;

/*
 * Thread creation by extending the Thread class
 */
class MyThread extends Thread
{
 public void run()
 {
  System.out.println("Concurrent thread started running..");
 }
}

class MyThreadDemo1
{
 public static void main( String args[] )
 {
  MyThread mt = new  MyThread();
  mt.start();
 }
}


