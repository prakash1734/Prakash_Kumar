package com.hsbc.java.training.demo.multithreading.threadfunction.nameid;

/*
 * getName(),setName(String) and getId() method
 */
class TestNameIdMethod1 extends Thread {
	public void run() {
		System.out.println("running...");
	}

	public static void main(String args[]) {
		TestNameIdMethod1 t1 = new TestNameIdMethod1();
		TestNameIdMethod1 t2 = new TestNameIdMethod1();
		System.out.println("Name of t1:" + t1.getName());
		System.out.println("Name of t2:" + t2.getName());
		System.out.println("id of t1:" + t1.getId());

		t1.start();
		t2.start();

		t1.setName("My Thread");
		System.out.println("After changing name of t1:" + t1.getName());
	}
}
