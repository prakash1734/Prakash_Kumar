package com.hsbc.java.training.demo.multithreading.synchronization;

/*
 * Example with synchronization keyword as method level
 */
class First3
{
 public void display(String msg)
 {
  System.out.print ("["+msg);
  try
  {
   Thread.sleep(1000);
  }
  catch(InterruptedException e)
  {
   e.printStackTrace();
  }
  System.out.println ("]");
 }
}

class Second3 extends Thread
{
 String msg;  
 First3 fobj;
 Second3 (First3 fp,String str)
 {
  fobj = fp;
  msg = str;
  start();
 }
 public void run()
 {
  synchronized(fobj)       //Synchronized block
  {
   fobj.display(msg);
  }
 }
}

public class WithSyncronizationMethodExample
{
 public static void main (String[] args) 
 {
  First3 fnew = new First3();
  Second3 ss = new Second3(fnew, "welcome");
  Second3 ss1= new Second3 (fnew,"new");
  Second3 ss2 = new Second3(fnew, "programmer");
 }
}


