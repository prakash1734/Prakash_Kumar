package com.hsbc.java.training.demo.exceptionhandling.methodoverriding;

class Super2 {
	void show() {
		System.out.println("parent class");
	}
}

public class UnCheckedExceptionExample extends Super2 {
	void show() throws ArrayIndexOutOfBoundsException // Correct
	{
		System.out.println("child class");
	}

	public static void main(String[] args) {
		Super2 s = new UnCheckedExceptionExample();
		s.show();
	}
}
