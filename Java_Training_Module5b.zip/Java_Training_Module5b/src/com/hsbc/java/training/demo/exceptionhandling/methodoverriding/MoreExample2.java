package com.hsbc.java.training.demo.exceptionhandling.methodoverriding;

/*
 * Example of Subclass overridden method with no Exception
 */

class Super4
{
 void show() throws Exception 
  {  System.out.println("parent class");  }
}

public class MoreExample2 extends Super4 {
 void show()             		//Correct  	  
   { System.out.println("child class"); } 

 public static void main(String[] args)
 {
  try {
   Super4 s=new MoreExample2();
   s.show();
   }
  catch(Exception e){}
 }  
}

