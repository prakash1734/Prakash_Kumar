package com.hsbc.java.training.demo.exceptionhandling.methodoverriding;

import java.io.IOException;

class Super1 {
	void show() {
		System.out.println("parent class");
	}
}

public class CheckedExceptionExample extends Super1 {
	void show() //throws IOException // If we uncomment this then will get Compile time error
	{
		System.out.println("parent class");
	}

	public static void main(String[] args) {
		Super1 s = new CheckedExceptionExample();
		s.show();
	}
}
