package com.hsbc.java.training.demo.exceptionhandling.trycatch;

/*
 * Example of try and catch
 */
public class TryCatchExample1 {
	public static void main(String args[]) {
		int a, b, c;
		try {
			a = 0;
			b = 10;
			c = b / a;
			System.out.println("This line will not be executed");
		} catch (ArithmeticException e) {
			System.out.println("Divided by zero");
		}
		System.out.println("After exception is handled");
	}
}
