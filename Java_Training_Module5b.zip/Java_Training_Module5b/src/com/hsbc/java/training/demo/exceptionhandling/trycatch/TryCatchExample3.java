package com.hsbc.java.training.demo.exceptionhandling.trycatch;

/*
 * Example for Unreachable Catch block
 */
public class TryCatchExample3 {
	public static void main(String[] args) {
		try {
			int arr[] = { 1, 2 };
			arr[2] = 3/0;
		} catch (Exception e) // This block handles all Exception
		{
			System.out.println("Generic exception");
			System.out.println(e.getMessage());
		} 
		
		/* This need to uncomment before run to understand this concept.
		 * This will give compilation error if we uncomment
		catch (ArrayIndexOutOfBoundsException e) // This block is unreachable
		{
			System.out.println("array index out of bound exception");
		}*/
	}
}
