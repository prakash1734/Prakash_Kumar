package com.hsbc.java.training.demo.exceptionhandling.methodoverriding;

/*
 * Example of Subclass overridden method with same Exception
 */

class Super3 {
	void show() throws Exception {
		System.out.println("parent class");
	}
}

public class MoreExample1 extends Super3 {
	void show() throws Exception // Correct
	{
		System.out.println("child class");
	}

	public static void main(String[] args) {
		try {
			Super3 s = new MoreExample1();
			s.show();
		} catch (Exception e) {
		}
	}
}
