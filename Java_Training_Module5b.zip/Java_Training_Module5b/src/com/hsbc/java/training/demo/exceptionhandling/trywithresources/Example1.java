package com.hsbc.java.training.demo.exceptionhandling.trywithresources;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/*
 * Example without using try with Resource Statement
 */

public class Example1 {
	public static void main(String[] args) {
		try {
			String str;
			// opening file in read mode using BufferedReader stream
			BufferedReader br = new BufferedReader(new FileReader("d:\\myfile.txt"));
			while ((str = br.readLine()) != null) {
				System.out.println(str);
			}
			br.close(); // closing BufferedReader stream
		} catch (IOException ie) {
			System.out.println("exception");
		}
	}
}
