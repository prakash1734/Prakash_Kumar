package com.hsbc.java.training.demo.exceptionhandling.methodoverriding;

/*
 * Example of Subclass overridden method with parent Exception
 */
class Super
{
 void show() throws ArithmeticException 
  {  System.out.println("parent class");  }
}

public class MoreExample3 extends Super {
 void show() //throws Exception  //If we uncomment this then will get Compile time error  	  
   { System.out.println("child class"); } 

 public static void main(String[] args)
 {
  try {
   Super s=new MoreExample3();
   s.show();
   }
  catch(Exception e){}
 }  
}

