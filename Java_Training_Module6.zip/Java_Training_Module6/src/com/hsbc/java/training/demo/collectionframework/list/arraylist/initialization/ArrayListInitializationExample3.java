package com.hsbc.java.training.demo.collectionframework.list.arraylist.initialization;

/*
 * Method3: Normal way of ArrayList initialization
 */
import java.util.*;

public class ArrayListInitializationExample3 {
	public static void main(String args[]) {
		ArrayList<String> books = new ArrayList<String>();
		books.add("Java Book1");
		books.add("Java Book2");
		books.add("Java Book3");
		System.out.println("Books stored in array list are: " + books);
	}
}
