package com.hsbc.java.training.demo.collectionframework.list.arraylist.initialization;

/*
 * Method 4: Use Collections.ncopies
 */
import java.util.*;

public class ArrayListInitializationExample4 {
   public static void main(String args[]) {
	   ArrayList<Integer> intlist = new ArrayList<Integer>(Collections.nCopies(10, 5));
	  System.out.println("ArrayList items: "+intlist);
   }
}
