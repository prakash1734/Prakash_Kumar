package com.hsbc.java.training.demo.collectionframework.set.treeset;

/*
 * Java program to demonstrate TreeSet creation from ArrayList
 */

import java.util.*;

class TreeSetDemo1 {
	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<String>();
		al.add("GeeksforGeeks");
		al.add("GeeksQuiz");
		al.add("Practice");
		al.add("Compiler");
		al.add("Compiler"); // will not be added

		// Creating a TreeSet object from ArrayList
		TreeSet<String> ts4 = new TreeSet<String>(al);

		// [Compiler,GeeksQuiz,GeeksforGeeks,Practice]
		System.out.println(ts4);
	}
}
