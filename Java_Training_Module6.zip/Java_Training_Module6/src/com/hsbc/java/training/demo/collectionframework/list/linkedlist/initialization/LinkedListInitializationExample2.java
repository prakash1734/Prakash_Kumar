package com.hsbc.java.training.demo.collectionframework.list.linkedlist.initialization;

/*
 * Method 2: Anonymous inner class method to initialize LinkedList
 */
import java.util.*;

public class LinkedListInitializationExample2 {
	public static void main(String args[]) {
		@SuppressWarnings("serial")
		LinkedList<String> cities = new LinkedList<String>() {
			{
				add("Delhi");
				add("Agra");
				add("Chennai");
			}
		};
		System.out.println("Content of Linked list cities:" + cities);
	}
}
