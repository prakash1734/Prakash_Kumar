package com.hsbc.java.training.demo.collectionframework.list.linkedlist.initialization;


/*
 * Method 1: Initialization using Arrays.asList
 */
import java.util.*;

public class LinkedListInitializationExample1 {
	public static void main(String args[]) {
		LinkedList<String> obj = new LinkedList<String>(Arrays.asList("Pratap", "Peter", "Harsh"));
		System.out.println("Elements are:" + obj);
	}
}

