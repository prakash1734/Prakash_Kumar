package com.hsbc.java.training.demo.collectionframework.legacy.properties;

/*
 * Java code illustrating list() method
 */
import java.io.PrintWriter;
import java.util.*;
class PropertiesDemoListPrintWriter
{

  
 public static void main(String arg[])
 {
     Properties gfg = new Properties();
      
     PrintWriter writer = new PrintWriter(System.out);
      
     gfg.put("ide", "ide.geeksforgeeks.org");
     gfg.put("contribute", "contribute.geeksforgeeks.org");
     gfg.put("quiz", "quiz.geeksforgeeks.org");
      
     // printing list using PrintWriter object
     gfg.list(writer);
      
     // flushing the stream
     writer.flush();
 }
}

