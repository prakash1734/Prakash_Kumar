package com.hsbc.java.training.demo.collectionframework.legacy.properties;

/*
 * Java code illustrating list() method
 */
import java.util.Properties;

class PropertiesDemoListPrintStream {
	public static void main(String arg[]) {
		Properties gfg = new Properties();

		gfg.put("ide", "ide.geeksforgeeks.org");
		gfg.put("contribute", "contribute.geeksforgeeks.org");
		gfg.put("quiz", "quiz.geeksforgeeks.org");

		gfg.list(System.out);
	}
}
