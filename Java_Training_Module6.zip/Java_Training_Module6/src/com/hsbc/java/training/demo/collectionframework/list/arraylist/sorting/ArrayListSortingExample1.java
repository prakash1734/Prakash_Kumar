package com.hsbc.java.training.demo.collectionframework.list.arraylist.sorting;
/*
 * Let�s see what�s the output when we try to sort arraylist of Objects without implementing any of these interfaces (comparable and comparator interfaces).
 */
import java.util.*;
public class ArrayListSortingExample1  {

     public static void main(String args[]){
	   ArrayList<Student> arraylist = new ArrayList<Student>();
	   arraylist.add(new Student(223, "Chaitanya", 26));
	   arraylist.add(new Student(245, "Rahul", 24));
	   arraylist.add(new Student(209, "Ajeet", 32));

	   //Collections.sort(arraylist);   // If we will uncomment this it will give compilation error

	   for(Student str: arraylist){
			System.out.println(str);
	   }
     }
}
