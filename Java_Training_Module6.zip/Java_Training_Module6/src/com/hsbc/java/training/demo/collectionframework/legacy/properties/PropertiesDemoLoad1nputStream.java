package com.hsbc.java.training.demo.collectionframework.legacy.properties;

/*
 * Java code illustrating load() method
 */
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;
class PropertiesDemoLoad1nputStream
{
 public static void main(String arg[]) throws IOException
 {
     Properties gfg = new Properties();
     String s = "ide = ide.geeksforgeeks.org";
      
     FileOutputStream out = new FileOutputStream("properties.txt");
     FileInputStream in = new FileInputStream("properties.txt");  
      
     // write the property in the output stream file
     out.write(s.getBytes());
      
     // load from input stream
     gfg.load(in);
      
     gfg.list(System.out);
     out.close();
 }
}

