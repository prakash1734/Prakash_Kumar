package com.hsbc.java.training.demo.collectionframework.list.arraylist.initialization;

/*
 * Method 2: Anonymous inner class method to initialize ArrayList
 */
import java.util.*;

public class ArrayListInitializationExample2 {
	public static void main(String args[]) {
		@SuppressWarnings("serial")
		ArrayList<String> cities = new ArrayList<String>() {
			{
				add("Delhi");
				add("Agra");
				add("Chennai");
			}
		};
		System.out.println("Content of Array list cities:" + cities);
	}
}
