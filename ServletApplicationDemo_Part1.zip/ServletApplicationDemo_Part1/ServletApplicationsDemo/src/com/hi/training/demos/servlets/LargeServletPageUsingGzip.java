package com.hi.training.demos.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hi.training.demos.GzipUtility;

/**
 * Servlet implementation class LargeServletPageUsingGzip
 */
@WebServlet("/LargeServletPageUsingGzip")
public class LargeServletPageUsingGzip extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LargeServletPageUsingGzip() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");

		PrintWriter out;

		if (GzipUtility.isGzipSupported(request) && !GzipUtility.isGzipDisabled(request)){
			out = GzipUtility.getGzipWriter(response);
		response.setHeader("Content-Encoding", "gzip");
		}
		else{
			out = response.getWriter();
		}

		String dummyLine = "This is dummy line just for understanding LargeServletPage concept";

		out.println("<!Doctype HTML>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Demo: Request Headers </title>");
		out.println("</head>");
		out.println("<body>");
		//out.println("Content-Encoding: " + response.getHeader("Content-Encoding"));

		for (int i = 0; i < 10000; i++) {
			out.println(dummyLine + "</br>");
		}
		out.println("</body>");
		out.println("</html>");
		out.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
